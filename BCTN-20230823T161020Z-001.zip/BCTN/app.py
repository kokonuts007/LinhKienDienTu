from flask import Flask, render_template,request,send_file,Response
import pickle
import numpy as np
import os, string, re
import tensorflow as tf
import recoment
from keras.models import load_model
import os,string,re,operator
from keras_radam import RAdam
from keras.preprocessing.sequence import pad_sequences
from pyvi import ViTokenizer, ViPosTagger
import os
app = Flask(__name__)


# Load hàm tiền xử lý dữ liệu. Cái hàm này được lấy từ trên quá trình huấn luyện ở file code google colab


with open('pickle/final_model.pkl', 'rb') as fp:
    model = pickle.load(fp)





# Đây là đoạn code xử lý code xây dựng ứng dụng: nếu địa chỉ IP vào là 127.0.0:5000 là sẽ trả file html "Home"
@app.route("/")
def home():
    return render_template("home.html")

@app.route("/dulieu")
def dulieu():
    return render_template("dulieu.html")


@app.route("/ketqua")
def phantichketqua():
    return render_template("ketqua.html")



# Hàm main chạy chương trình web Flask trên local
if __name__ == "__main__":
    app.run()
