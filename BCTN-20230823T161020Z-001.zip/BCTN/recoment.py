import numpy as np
import pandas as pd
from scipy.sparse import csr_matrix
import keras
import os
import sys
import pickle
import implicit
import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)

with open('pickle/final_model.pkl', 'rb') as fp:
    model = pickle.load(fp)

def classify(text):
    tmp = []
    tmp.append(text)
    predict = model.predict(tmp)

    return predict